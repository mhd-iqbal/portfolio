<?php

class Services_model extends CIF_model
{
    public $_table = 'services';
    public $_primary_keys = array('service_id');
}
