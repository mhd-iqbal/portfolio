<?php

class Testimonials_model extends CIF_model
{
    public $_table = 'testimonials';
    public $_primary_keys = array('testimonial_id');


}
